import pytest

from app.sql_validator import UnsafeSQLError, validate_sql

ALLOWED = {"products", "orders", "order_items"}


def test_simple_select_gets_limit():
    assert validate_sql("SELECT * FROM products", ALLOWED, 50).endswith("LIMIT 50")


def test_trailing_semicolon_is_ok():
    assert "SELECT" in validate_sql("SELECT name FROM products;", ALLOWED)


def test_large_limit_is_capped():
    assert validate_sql("SELECT * FROM orders LIMIT 5000", ALLOWED, 100).endswith("LIMIT 100")


def test_small_limit_is_kept():
    assert validate_sql("SELECT * FROM orders LIMIT 5", ALLOWED, 100).endswith("LIMIT 5")


def test_join_and_cte_allowed():
    sql = (
        "WITH totals AS (SELECT order_id, SUM(quantity) AS q FROM order_items GROUP BY order_id) "
        "SELECT o.id, t.q FROM orders o JOIN totals t ON t.order_id = o.id"
    )
    validate_sql(sql, ALLOWED)


@pytest.mark.parametrize("sql", [
    "DROP TABLE products",
    "DELETE FROM orders",
    "UPDATE products SET price = 0",
    "INSERT INTO products VALUES (1)",
    "SELECT * FROM products; DROP TABLE orders",
    "SELECT * FROM products WHERE 1=1; DELETE FROM orders",
    "WITH x AS (DELETE FROM orders RETURNING *) SELECT * FROM x",
    "SELECT * INTO new_table FROM products",
    "PRAGMA table_info(products)",
    "",
    "   ;  ",
])
def test_dangerous_or_invalid_sql_is_blocked(sql):
    with pytest.raises(UnsafeSQLError):
        validate_sql(sql, ALLOWED)


def test_comment_tricks_are_blocked():
    with pytest.raises(UnsafeSQLError):
        validate_sql("SELECT 1 /* hi */; /* x */ DROP TABLE products", ALLOWED)


def test_table_outside_role_is_blocked():
    with pytest.raises(UnsafeSQLError):
        validate_sql("SELECT * FROM customers", ALLOWED)
    with pytest.raises(UnsafeSQLError):
        validate_sql("SELECT * FROM products p JOIN customers c ON 1=1", ALLOWED)


def test_app_tables_are_never_reachable():
    with pytest.raises(UnsafeSQLError):
        validate_sql("SELECT * FROM app_users", ALLOWED)


def test_schema_qualified_names_are_blocked():
    with pytest.raises(UnsafeSQLError):
        validate_sql("SELECT * FROM main.app_users", ALLOWED)


def test_keywords_inside_string_literals_are_fine():
    validate_sql("SELECT * FROM products WHERE name = 'drop; delete'", ALLOWED)


def test_column_names_containing_keywords_are_fine():
    validate_sql("SELECT created_at, updated_at FROM orders", ALLOWED)
