import os
import tempfile

# Configure the app BEFORE importing it.
_tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["LLM_PROVIDER"] = "mock"
os.environ["JWT_SECRET"] = "test-secret"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.llm import MockClient  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:  # runs lifespan: creates tables and seeds data
        yield c


def login(client, username, password):
    res = client.post("/auth/login", data={"username": username, "password": password})
    assert res.status_code == 200
    return {"Authorization": f"Bearer {res.json()['access_token']}"}


def test_query_requires_login(client):
    assert client.post("/query", json={"question": "anything"}).status_code == 401


def test_bad_password(client):
    assert client.post("/auth/login", data={"username": "admin", "password": "nope"}).status_code == 401


def test_successful_query(client):
    MockClient.response = "SELECT category, COUNT(*) AS n FROM products GROUP BY category"
    res = client.post("/query", json={"question": "products per category"}, headers=login(client, "analyst", "analyst123"))
    assert res.status_code == 200
    body = res.json()
    assert body["columns"] == ["category", "n"]
    assert body["row_count"] == 4


def test_destructive_sql_from_llm_is_blocked(client):
    MockClient.response = "DROP TABLE products"
    res = client.post("/query", json={"question": "delete everything"}, headers=login(client, "admin", "admin123"))
    assert res.status_code == 400
    # the table is still there
    MockClient.response = "SELECT COUNT(*) AS n FROM products"
    ok = client.post("/query", json={"question": "count"}, headers=login(client, "admin", "admin123"))
    assert ok.json()["rows"][0][0] == 13


def test_rbac_customers_table(client):
    MockClient.response = "SELECT name FROM customers"
    user = client.post("/query", json={"question": "customers"}, headers=login(client, "analyst", "analyst123"))
    admin = client.post("/query", json={"question": "customers"}, headers=login(client, "admin", "admin123"))
    assert user.status_code == 400
    assert admin.status_code == 200


def test_history_is_scoped_by_role(client):
    admin = client.get("/history", headers=login(client, "admin", "admin123")).json()
    analyst = client.get("/history", headers=login(client, "analyst", "analyst123")).json()
    assert {h["username"] for h in analyst} == {"analyst"}
    assert {"admin", "analyst"} <= {h["username"] for h in admin}
