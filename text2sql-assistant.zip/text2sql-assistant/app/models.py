"""Demo business schema (queried by the LLM) plus app tables (users, query log)."""
from datetime import datetime

from sqlalchemy import Column, Date, DateTime, Float, ForeignKey, Integer, String, Text

from .database import Base


class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(120), nullable=False)
    country = Column(String(60), nullable=False)
    created_at = Column(Date, nullable=False)


class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    category = Column(String(60), nullable=False)
    price = Column(Float, nullable=False)


class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False)
    order_date = Column(Date, nullable=False)
    status = Column(String(20), nullable=False)  # PAID | SHIPPED | CANCELLED


class OrderItem(Base):
    __tablename__ = "order_items"
    id = Column(Integer, primary_key=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Float, nullable=False)


# ---- application tables: never exposed to the LLM ----
class AppUser(Base):
    __tablename__ = "app_users"
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(10), nullable=False, default="USER")  # ADMIN | USER


class QueryLog(Base):
    __tablename__ = "query_logs"
    id = Column(Integer, primary_key=True)
    username = Column(String(50), nullable=False)
    question = Column(Text, nullable=False)
    generated_sql = Column(Text)
    status = Column(String(20), nullable=False)  # OK | BLOCKED | ERROR
    row_count = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)


# Tables the LLM may see / query, per role (RBAC).
USER_TABLES = {"products", "orders", "order_items"}
ADMIN_TABLES = USER_TABLES | {"customers"}


def tables_for_role(role: str) -> set[str]:
    return ADMIN_TABLES if role == "ADMIN" else USER_TABLES
