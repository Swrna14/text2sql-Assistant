"""FastAPI entrypoint: auth, schema, natural-language query and history endpoints."""
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException
from fastapi.encoders import jsonable_encoder
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from sqlalchemy import inspect
from sqlalchemy.orm import Session

from .auth import create_token, get_current_user, hash_password, verify_password
from .config import settings
from .database import Base, SessionLocal, engine, get_db
from .llm import get_llm
from .models import AppUser, QueryLog, tables_for_role
from .schemas import HistoryItem, QueryRequest, QueryResponse, RegisterRequest, TokenResponse
from .seed import seed
from .sql_validator import UnsafeSQLError, validate_sql

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("text2sql")


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed(db)
    yield


app = FastAPI(
    title="Text-to-SQL Assistant",
    description="Ask questions in plain English; an LLM writes SQL, a validator makes it safe, the DB answers.",
    version="1.0.0",
    lifespan=lifespan,
)


def describe_schema(allowed: set[str]) -> str:
    """Compact schema text for the prompt, limited to the tables this role may query."""
    inspector = inspect(engine)
    lines = []
    for table in sorted(allowed):
        cols = ", ".join(f"{c['name']} {c['type']}" for c in inspector.get_columns(table))
        lines.append(f"{table}({cols})")
    return "\n".join(lines)


def run_readonly(sql: str, max_rows: int):
    """Execute inside a read-only transaction and cap the rows returned."""
    with engine.connect() as conn:
        dialect = engine.dialect.name
        if dialect == "sqlite":
            conn.exec_driver_sql("PRAGMA query_only = ON")
        elif dialect == "postgresql":
            conn.exec_driver_sql("SET TRANSACTION READ ONLY")
        elif dialect == "mysql":
            conn.exec_driver_sql("SET SESSION TRANSACTION READ ONLY")
        result = conn.exec_driver_sql(sql)
        columns = list(result.keys())
        rows = result.fetchmany(max_rows + 1)
    return columns, rows


# ----------------------------- auth -----------------------------
@app.post("/auth/register", response_model=TokenResponse, status_code=201, tags=["auth"])
def register(body: RegisterRequest, db: Session = Depends(get_db)):
    if db.query(AppUser).filter(AppUser.username == body.username).first():
        raise HTTPException(409, "Username already taken")
    user = AppUser(username=body.username, password_hash=hash_password(body.password), role="USER")
    db.add(user)
    db.commit()
    return TokenResponse(access_token=create_token(user.username, user.role), role=user.role)


@app.post("/auth/login", response_model=TokenResponse, tags=["auth"])
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(AppUser).filter(AppUser.username == form.username).first()
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(401, "Incorrect username or password")
    return TokenResponse(access_token=create_token(user.username, user.role), role=user.role)


# ----------------------------- data -----------------------------
@app.get("/schema", tags=["query"])
def schema(user: AppUser = Depends(get_current_user)):
    return {"role": user.role, "tables": describe_schema(tables_for_role(user.role)).splitlines()}


@app.post("/query", response_model=QueryResponse, tags=["query"])
def query(body: QueryRequest, user: AppUser = Depends(get_current_user), db: Session = Depends(get_db)):
    allowed = tables_for_role(user.role)
    entry = QueryLog(username=user.username, question=body.question, status="ERROR")
    db.add(entry)
    try:
        raw_sql = get_llm().generate_sql(body.question, describe_schema(allowed), engine.dialect.name)
        entry.generated_sql = raw_sql
        safe_sql = validate_sql(raw_sql, allowed, settings.MAX_ROWS)
        columns, rows = run_readonly(safe_sql, settings.MAX_ROWS)
    except UnsafeSQLError as exc:
        entry.status = "BLOCKED"
        db.commit()
        log.warning("Blocked SQL for %s: %s", user.username, exc)
        raise HTTPException(400, f"Generated SQL was blocked: {exc}")
    except HTTPException:
        raise
    except Exception as exc:  # LLM or database failure
        db.commit()
        log.exception("Query failed")
        raise HTTPException(502, f"Could not answer that question: {exc}")

    truncated = len(rows) > settings.MAX_ROWS
    rows = rows[: settings.MAX_ROWS]
    entry.status, entry.row_count = "OK", len(rows)
    db.commit()
    return QueryResponse(
        question=body.question, sql=safe_sql, columns=columns,
        rows=jsonable_encoder([list(r) for r in rows]), row_count=len(rows), truncated=truncated,
    )


@app.get("/history", response_model=list[HistoryItem], tags=["query"])
def history(user: AppUser = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(QueryLog).order_by(QueryLog.id.desc())
    if user.role != "ADMIN":  # users only see their own history; admins see everyone's
        q = q.filter(QueryLog.username == user.username)
    return q.limit(50).all()


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok"}


# Static UI (mounted last so API routes win)
_frontend = Path(__file__).resolve().parent.parent / "frontend"
if _frontend.exists():
    app.mount("/", StaticFiles(directory=_frontend, html=True), name="ui")
