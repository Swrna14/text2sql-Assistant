"""Application settings, read from environment variables (or a local .env file)."""
import os

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # python-dotenv is optional
    pass


class Settings:
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./demo.db")
    JWT_SECRET: str = os.getenv("JWT_SECRET", "change-me-in-production")
    JWT_EXPIRE_MINUTES: int = int(os.getenv("JWT_EXPIRE_MINUTES", "60"))
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "gemini")  # gemini | mock
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    MAX_ROWS: int = int(os.getenv("MAX_ROWS", "100"))


settings = Settings()
