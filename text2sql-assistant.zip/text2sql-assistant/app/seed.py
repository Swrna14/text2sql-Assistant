"""Synthetic demo data. Safe to publish: nothing here is real."""
import random
from datetime import date, timedelta

from sqlalchemy.orm import Session

from .auth import hash_password
from .models import AppUser, Customer, Order, OrderItem, Product

COUNTRIES = ["India", "USA", "Germany", "UK", "Japan", "Brazil", "Canada"]
CATALOG = [
    ("Laptop", "Electronics", 899.0), ("Phone", "Electronics", 599.0),
    ("Headphones", "Electronics", 129.0), ("Monitor", "Electronics", 249.0),
    ("Desk", "Furniture", 320.0), ("Chair", "Furniture", 180.0), ("Bookshelf", "Furniture", 140.0),
    ("Notebook", "Stationery", 4.5), ("Pen Set", "Stationery", 12.0), ("Planner", "Stationery", 18.0),
    ("Running Shoes", "Sports", 95.0), ("Yoga Mat", "Sports", 35.0), ("Dumbbells", "Sports", 60.0),
]


def seed(db: Session) -> None:
    if db.query(AppUser).first():
        return  # already seeded

    # Demo accounts - for local use only. Change or remove before deploying.
    db.add_all([
        AppUser(username="admin", password_hash=hash_password("admin123"), role="ADMIN"),
        AppUser(username="analyst", password_hash=hash_password("analyst123"), role="USER"),
    ])

    rng = random.Random(42)
    today = date.today()
    customers = [
        Customer(name=f"Customer {i}", email=f"customer{i}@example.com",
                 country=rng.choice(COUNTRIES), created_at=today - timedelta(days=rng.randint(30, 700)))
        for i in range(1, 41)
    ]
    products = [Product(name=n, category=c, price=p) for n, c, p in CATALOG]
    db.add_all(customers + products)
    db.flush()

    for _ in range(300):
        order = Order(customer_id=rng.choice(customers).id,
                      order_date=today - timedelta(days=rng.randint(0, 365)),
                      status=rng.choices(["PAID", "SHIPPED", "CANCELLED"], [5, 4, 1])[0])
        db.add(order)
        db.flush()
        for product in rng.sample(products, rng.randint(1, 4)):
            db.add(OrderItem(order_id=order.id, product_id=product.id,
                             quantity=rng.randint(1, 5), unit_price=product.price))
    db.commit()
