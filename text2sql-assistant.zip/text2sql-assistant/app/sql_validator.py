"""Safety layer: only a single, read-only SELECT on allowed tables may reach the database.

The LLM is treated as untrusted. Everything it returns goes through validate_sql().
Defence in depth: the executor also opens a read-only transaction and caps the row count,
and in production you should connect with a database user that only has SELECT rights.
"""
import re


class UnsafeSQLError(ValueError):
    """Raised when generated SQL fails validation."""


FORBIDDEN_KEYWORDS = {
    "insert", "update", "delete", "drop", "alter", "create", "truncate", "grant",
    "revoke", "merge", "call", "exec", "execute", "attach", "detach", "pragma",
    "vacuum", "copy", "into", "outfile", "dumpfile", "load_file", "sleep",
    "benchmark", "pg_sleep",
}

_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.S)
_LINE_COMMENT = re.compile(r"--[^\n]*")
_STRING_LITERAL = re.compile(r"'(?:[^']|'')*'")
_TABLE_REF = re.compile(r"\b(?:from|join)\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)?)", re.I)
_CTE_NAME = re.compile(r"\b([A-Za-z_]\w*)\s+as\s*\(", re.I)
_TRAILING_LIMIT = re.compile(r"\blimit\s+(\d+)\s*$", re.I)


def validate_sql(sql: str, allowed_tables: set[str], max_rows: int = 100) -> str:
    """Return a safe version of `sql` or raise UnsafeSQLError."""
    if not sql or not sql.strip():
        raise UnsafeSQLError("Empty query.")

    cleaned = _BLOCK_COMMENT.sub(" ", sql)
    cleaned = _LINE_COMMENT.sub(" ", cleaned).strip().rstrip(";").strip()
    if not cleaned:
        raise UnsafeSQLError("Empty query.")

    # Ignore string contents when looking at structure, so 'a;b' or 'drop' in text is fine.
    scrubbed = _STRING_LITERAL.sub("''", cleaned).lower()

    if ";" in scrubbed:
        raise UnsafeSQLError("Multiple statements are not allowed.")
    if scrubbed.split(None, 1)[0] not in {"select", "with"}:
        raise UnsafeSQLError("Only SELECT queries are allowed.")

    for word in FORBIDDEN_KEYWORDS:
        if re.search(rf"\b{word}\b", scrubbed):
            raise UnsafeSQLError(f"Forbidden keyword: {word.upper()}")

    allowed = {t.lower() for t in allowed_tables}
    ctes = {c.lower() for c in _CTE_NAME.findall(scrubbed)}
    for ref in _TABLE_REF.findall(scrubbed):
        if "." in ref:
            raise UnsafeSQLError("Schema-qualified table names are not allowed.")
        if ref.lower() not in allowed and ref.lower() not in ctes:
            raise UnsafeSQLError(f"Access to table '{ref}' is not permitted for your role.")

    # Cap the result size.
    match = _TRAILING_LIMIT.search(cleaned)
    if match:
        if int(match.group(1)) > max_rows:
            cleaned = cleaned[: match.start()] + f"LIMIT {max_rows}"
    elif not re.search(r"\blimit\b", scrubbed):
        cleaned = f"{cleaned} LIMIT {max_rows}"
    return cleaned
