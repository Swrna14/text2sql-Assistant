"""LLM wrapper. Gemini by default; a mock provider keeps tests and demos key-free."""
import re

from .config import settings

SYSTEM_PROMPT = """You are a careful data analyst that writes {dialect} SQL.
Rules:
- Return ONE read-only SELECT statement and nothing else (no explanation, no markdown).
- Use only the tables and columns in the schema below.
- Never modify data. Add ORDER BY and LIMIT where sensible.
- If the question cannot be answered from the schema, return: SELECT 'cannot answer' AS message

Schema:
{schema}

Question: {question}
SQL:"""


def extract_sql(text: str) -> str:
    """Strip markdown fences and whitespace the model may add."""
    match = re.search(r"```(?:sql)?\s*(.*?)```", text, re.S | re.I)
    return (match.group(1) if match else text).strip()


class GeminiClient:
    def __init__(self):
        if not settings.GEMINI_API_KEY:
            raise RuntimeError("GEMINI_API_KEY is not set (or use LLM_PROVIDER=mock).")
        from google import genai  # imported lazily so tests don't need the package

        self._client = genai.Client(api_key=settings.GEMINI_API_KEY)

    def generate_sql(self, question: str, schema: str, dialect: str) -> str:
        prompt = SYSTEM_PROMPT.format(dialect=dialect, schema=schema, question=question)
        response = self._client.models.generate_content(model=settings.GEMINI_MODEL, contents=prompt)
        return extract_sql(response.text or "")


class MockClient:
    """Deterministic stand-in used in tests and for trying the UI without an API key."""

    response = "SELECT category, COUNT(*) AS products FROM products GROUP BY category ORDER BY products DESC"

    def generate_sql(self, question: str, schema: str, dialect: str) -> str:
        return self.response


_client = None


def get_llm():
    global _client
    if _client is None:
        _client = MockClient() if settings.LLM_PROVIDER == "mock" else GeminiClient()
    return _client
